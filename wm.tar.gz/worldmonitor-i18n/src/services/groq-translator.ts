/**
 * Groq-based news translator
 * Uses Groq's OpenAI-compatible API for Chinese translation
 */

interface TranslationCache {
  [key: string]: {
    translatedTitle: string;
    translatedSummary?: string;
    timestamp: number;
  };
}

const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

// In-memory cache (persisted to localStorage separately)
const translationCache: TranslationCache = {};

export async function translateNews(
  title: string,
  summary?: string,
  apiKey?: string
): Promise<{ title: string; summary?: string }> {
  // Build cache key from source text
  const cacheKey = `trans_${btoa(title)}${summary ? '_' + btoa(summary) : ''}`;

  // Check memory cache first
  const cached = translationCache[cacheKey];
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return {
      title: cached.translatedTitle,
      summary: cached.translatedSummary,
    };
  }

  // Get API key from env, parameter, or localStorage (for user-provided keys)
  const key = apiKey || import.meta.env.VITE_GROQ_API_KEY || localStorage.getItem('groq-api-key');
  if (!key) {
    console.warn('[Translator] No Groq API key configured');
    return { title, summary };
  }

  try {
    // Build translation prompt
    const prompt = summary
      ? `Translate the following news title and summary to Chinese (Simplified). Keep it natural and concise.\n\nTitle: ${title}\n\nSummary: ${summary}`
      : `Translate the following news title to Chinese (Simplified). Keep it natural and concise.\n\nTitle: ${title}`;

    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'meta-llama/llama-4-scout-17b-16e-instruct', // Fast, good quality
        messages: [
          {
            role: 'system',
            content: 'You are a professional translator. Translate to Chinese (Simplified) only, no explanations.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.3,
        max_tokens: 512,
      }),
    });

    if (!response.ok) {
      throw new Error(`Groq API error: ${response.status}`);
    }

    const data = await response.json();
    const translated = data.choices?.[0]?.message?.content?.trim();

    if (!translated) {
      throw new Error('No translation returned');
    }

    // Parse result (title + optional summary)
    let translatedTitle = translated;
    let translatedSummary: string | undefined;

    if (summary) {
      // Expect format: "Title: ...\n\nSummary: ..." or just the translated text
      const parts = translated.split('\n\n');
      if (parts.length >= 2) {
        translatedTitle = parts[0].replace(/^Title:\s*/i, '').trim();
        translatedSummary = parts[1].replace(/^Summary:\s*/i, '').trim();
      } else {
        // Fallback: translate separately
        translatedTitle = translated;
        // Optionally: could call API again for summary, but skip for now
      }
    }

    // Cache in memory
    translationCache[cacheKey] = {
      translatedTitle,
      translatedSummary,
      timestamp: Date.now(),
    };

    return {
      title: translatedTitle,
      summary: translatedSummary,
    };
  } catch (error) {
    console.error('[Translator] Translation failed:', error);
    return { title, summary }; // Fallback to original
  }
}

/**
 * Persist translation cache to localStorage (call on page hide/unload)
 */
export function persistTranslationCache(): void {
  try {
    const toPersist: Record<string, { translatedTitle: string; translatedSummary?: string; timestamp: number }> = {};
    for (const [key, val] of Object.entries(translationCache)) {
      // Only persist fresh entries (within TTL)
      if (Date.now() - val.timestamp < CACHE_TTL) {
        toPersist[key] = val;
      }
    }
    localStorage.setItem('worldmonitor-translation-cache', JSON.stringify(toPersist));
  } catch (e) {
    console.warn('[Translator] Failed to persist cache:', e);
  }
}

/**
 * Load translation cache from localStorage (call on startup)
 */
export function loadTranslationCache(): void {
  try {
    const stored = localStorage.getItem('worldmonitor-translation-cache');
    if (stored) {
      const parsed: Record<string, { translatedTitle: string; translatedSummary?: string; timestamp: number }> = JSON.parse(stored);
      for (const [key, val] of Object.entries(parsed)) {
        // Only load if still valid
        if (Date.now() - val.timestamp < CACHE_TTL) {
          translationCache[key] = val;
        }
      }
      console.log('[Translator] Cache loaded:', Object.keys(translationCache).length, 'entries');
    }
  } catch (e) {
    console.warn('[Translator] Failed to load cache:', e);
  }
}
